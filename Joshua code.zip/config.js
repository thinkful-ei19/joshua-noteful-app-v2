'use strict';

exports.PORT = process.env.PORT||8080;